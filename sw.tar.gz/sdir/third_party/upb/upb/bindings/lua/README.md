
# upb Lua bindings

These are some bare-bones upb bindings for Lua.

These bindings exist primarily for experimentation and testing.  They are
incomplete and are not really intended for use in any application.  This is by
no means a complete or supported protobuf library.
